
def capacity ( item ) :

	return item.capacity

def size ( item ) :

	return item.size

def row ( item ) :

	return item.row
